Hello! Please enjoy this Logic AI SAT Solver. To run, use terminal to run the following commands (file is the cnf file you want to run and solver is either 'walksat' or 'gsat':

/solve_sudoky.py \<file.cnf\> \<solver\>